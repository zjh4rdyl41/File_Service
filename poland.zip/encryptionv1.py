﻿import base64
import marshal
import zlib
import sys
import random
import textwrap
import hashlib
import secrets


def rc4(data, key):
    S = list(range(256))
    j = 0
    out = []
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    for char in data:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out.append(char ^ S[(S[i] + S[j]) % 256])
    return bytes(out)


def pseudo_chacha20_xor(key, nonce, data):
    seed = int.from_bytes(hashlib.sha256(key + nonce).digest(), 'big')
    rnd = random.Random(seed)
    keystream = bytes(rnd.getrandbits(8) for _ in range(len(data)))
    return bytes(b ^ k for b, k in zip(data, keystream))


def compress(code_bytes: bytes) -> bytes:
    return zlib.compress(code_bytes)


def generate_key(length=32):
    return bytes(random.choices(range(256), k=length))


# def obfuscate_name(name):
#     h = hashlib.shake_128(name.encode()).hexdigest(8)
#     return f"_{h}"
def obfuscate_name(name):
        return "_" + ''.join(secrets.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(10))


def encrypt_file(input_file: str, output_file: str):
    with open(input_file, "r", encoding="utf-8") as f:
        source_code = f.read()

    original_code_object = compile(source_code, "<string>", "exec")
    original_bytecode = marshal.dumps(original_code_object)

    key1 = generate_key(32)
    key2 = generate_key(16)
    nonce = generate_key(12)

    chacha_encrypted = pseudo_chacha20_xor(key1, nonce, original_bytecode)
    encrypted_payload = rc4(chacha_encrypted, key2)

    payload_hash = hashlib.sha3_256(encrypted_payload).digest()

    k1_name = obfuscate_name("key1")
    k2_name = obfuscate_name("key2")
    nonce_name = obfuscate_name("nonce")
    enc_name = obfuscate_name("encrypted")
    hash_name = obfuscate_name("payload_hash")

    runtime_code = f'''
import marshal, zlib, base64, hashlib, random, sys

def rc4(data, key):
    S = list(range(256))
    j = 0
    out = []
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    for char in data:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out.append(char ^ S[(S[i] + S[j]) % 256])
    return bytes(out)

def pseudo_chacha20_xor(key, nonce, data):
    seed = int.from_bytes(hashlib.sha256(key + nonce).digest(), 'big')
    rnd = random.Random(seed)
    keystream = bytes(rnd.getrandbits(8) for _ in range(len(data)))
    return bytes(b ^ k for b, k in zip(data, keystream))

def check_integrity(data, expected_hash):
    h = hashlib.sha3_256(data).digest()
    return h == expected_hash

def stealth_decrypt():
    {k1_name} = bytes({list(key1)})
    {k2_name} = bytes({list(key2)})
    {nonce_name} = bytes({list(nonce)})
    {enc_name} = bytes({list(encrypted_payload)})
    {hash_name} = bytes({list(payload_hash)})

    if not check_integrity({enc_name}, {hash_name}):
        return b""

    try:
        step1 = rc4({enc_name}, {k2_name})
        step2 = pseudo_chacha20_xor({k1_name}, {nonce_name}, step1)
        return step2
    except Exception:
        return b""
if(sys.argv[1] != "Chocopie"):
    sys.exit()
payload = stealth_decrypt()

state = 0
while True:
    if state == 0:
        state = 1
    elif state == 1:
        if payload:
            exec(marshal.loads(payload))
        state = 2
    elif state == 2:
        break
'''

    runtime_code_object = compile(textwrap.dedent(runtime_code), "<string>", "exec")
    runtime_bytecode = marshal.dumps(runtime_code_object)

    compressed = compress(runtime_bytecode)
    base85_encoded = base64.b85encode(compressed).decode()

    output_code = f'import base64,zlib,marshal\nexec(marshal.loads(zlib.decompress(base64.b85decode("{base85_encoded}"))))'

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(output_code)

    print(f"[✓] SuccessFull")


if __name__ == "__main__":
    if len(sys.argv) !=3:
        print("Cách dùng: python encrypter.py <file> <output>")
        sys.exit(1)
    encrypt_file(sys.argv[1], sys.argv[2])
